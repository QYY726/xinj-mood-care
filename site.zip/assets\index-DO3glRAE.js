(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))e(a);new MutationObserver(a=>{for(const o of a)if(o.type==="childList")for(const r of o.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&e(r)}).observe(document,{childList:!0,subtree:!0});function n(a){const o={};return a.integrity&&(o.integrity=a.integrity),a.referrerPolicy&&(o.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?o.credentials="include":a.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function e(a){if(a.ep)return;a.ep=!0;const o=n(a);fetch(a.href,o)}})();const m=[{id:"calm",name:"平静",emoji:"🌿",score:4},{id:"happy",name:"开心",emoji:"☀️",score:5},{id:"anxious",name:"焦虑",emoji:"🌊",score:2},{id:"tired",name:"疲惫",emoji:"🌙",score:2},{id:"sad",name:"低落",emoji:"🌧️",score:1},{id:"angry",name:"烦躁",emoji:"🔥",score:1},{id:"lonely",name:"孤独",emoji:"🍂",score:2},{id:"hopeful",name:"期待",emoji:"🌱",score:4},{id:"stressed",name:"压力",emoji:"⚡",score:1},{id:"grateful",name:"感恩",emoji:"🍃",score:5}],$=["学业 deadline","职场会议","人际关系","睡眠不足","社交比较","家庭关系","身体状态","财务压力","自我苛责","突发变化"],f={anxious:[{type:"冥想",title:"4-7-8 呼吸锚定",desc:"吸气4秒、屏息7秒、呼气8秒，重复4轮，让神经系统慢下来。",mins:5},{type:"音乐",title:"低频白噪音清单",desc:"听雨声或轻柔钢琴，把注意力从担忧回路里轻轻拉开。",mins:10},{type:"运动",title:"快走释放紧张",desc:"出门快走10分钟，同步数呼吸，把身体里的紧张带走。",mins:10}],tired:[{type:"冥想",title:"身体扫描小憩",desc:"从脚趾到头顶依次放松，允许自己短暂停机充电。",mins:8},{type:"音乐",title:"柔和氛围曲",desc:"选无歌词的氛围乐，降低信息输入，给大脑留白。",mins:15},{type:"运动",title:"拉伸唤醒",desc:"肩颈与髋部轻柔拉伸，而不是高强度消耗。",mins:7}],sad:[{type:"冥想",title:"自我关怀短句",desc:"把手放胸口，重复：我现在很难，但这会过去。",mins:5},{type:"音乐",title:"温暖民谣",desc:"听一首熟悉而温柔的歌，允许情绪被看见。",mins:6},{type:"运动",title:"晒太阳散步",desc:"走到有光的地方慢慢走，让身体重新接上外界。",mins:12}],angry:[{type:"冥想",title:"命名情绪",desc:"大声说出：我感到烦躁，因为……。命名能降低强度。",mins:4},{type:"音乐",title:"节奏释放",desc:"先听有力量的鼓点，再切到舒缓曲，完成情绪过渡。",mins:10},{type:"运动",title:"高强度短冲",desc:"原地开合跳或快跑2分钟，把怒气转化为动能。",mins:5}],stressed:[{type:"冥想",title:"三物专注法",desc:"说出眼前3样颜色、听到3种声音、触碰3种质感。",mins:3},{type:"音乐",title:"专注深工作曲",desc:"Lo-fi 或自然声，帮你把压力拆成一个可执行小任务。",mins:20},{type:"运动",title:"方块呼吸行走",desc:"边走边做4-4-4-4呼吸，重新拿回掌控感。",mins:8}],lonely:[{type:"冥想",title:"写信给自己",desc:"写下你希望朋友对你说的话，再读给自己听。",mins:8},{type:"音乐",title:"陪伴向歌单",desc:"选你会跟朋友一起听的歌，制造温柔的连接感。",mins:12},{type:"运动",title:"公共空间漫步",desc:"去公园或咖啡馆走一圈，感受人群的背景温度。",mins:15}],default:[{type:"冥想",title:"今日三件好事",desc:"写下三件微小的好事，训练大脑看见资源。",mins:5},{type:"音乐",title:"清晨清透歌单",desc:"轻快但不刺激的节奏，帮你稳住当下状态。",mins:10},{type:"运动",title:"伸展+深呼吸",desc:"站立伸展配合深呼吸，延续这份好状态。",mins:6}]},u="moodcare-entries-v1",y=()=>{const i=Date.now();return[{id:"s1",moodId:"anxious",intensity:7,triggers:["学业 deadline","睡眠不足"],note:"论文改到半夜，早上起来心跳有点快。",createdAt:i-864e5*2},{id:"s2",moodId:"tired",intensity:6,triggers:["职场会议","身体状态"],note:"连续开会，脑子转不动。",createdAt:i-864e5},{id:"s3",moodId:"grateful",intensity:8,triggers:["人际关系"],note:"朋友发来鼓励，心里暖了一下。",createdAt:i-36e5*5}]},s={view:"home",entries:w(),draft:{moodId:"calm",intensity:5,triggers:[],note:""},toast:""};function w(){try{const i=localStorage.getItem(u);if(!i){const t=y();return localStorage.setItem(u,JSON.stringify(t)),t}return JSON.parse(i)}catch{return y()}}function S(){localStorage.setItem(u,JSON.stringify(s.entries))}function l(i){return m.find(t=>t.id===i)||m[0]}function j(i){const t=new Date(i),n=new Date,e=t.toDateString()===n.toDateString(),a=String(t.getHours()).padStart(2,"0"),o=String(t.getMinutes()).padStart(2,"0");return e?`今天 ${a}:${o}`:`${t.getMonth()+1}/${t.getDate()} ${a}:${o}`}function p(i){s.toast=i,v(),setTimeout(()=>{s.toast="";const t=document.querySelector(".toast");t&&t.classList.remove("show")},1800)}function I(i){const t={};return i.forEach(n=>{n.triggers.forEach(e=>{t[e]=t[e]||{count:0,intensity:0,moods:{}},t[e].count+=1,t[e].intensity+=n.intensity,t[e].moods[n.moodId]=(t[e].moods[n.moodId]||0)+1})}),Object.entries(t).map(([n,e])=>{var a;return{name:n,count:e.count,avg:+(e.intensity/e.count).toFixed(1),topMood:(a=Object.entries(e.moods).sort((o,r)=>r[1]-o[1])[0])==null?void 0:a[0]}}).sort((n,e)=>e.count-n.count||e.avg-n.avg)}function E(i){const t=[];for(let n=6;n>=0;n--){const e=new Date;e.setHours(0,0,0,0),e.setDate(e.getDate()-n);const a=e.toDateString(),o=i.filter(d=>new Date(d.createdAt).toDateString()===a),r=o.length?o.reduce((d,c)=>d+l(c.moodId).score,0)/o.length:0;t.push({label:`${e.getMonth()+1}/${e.getDate()}`,avg:r,count:o.length})}return t}function x(i){return f[i]||f.default}function g(i){s.view=i,v(),window.scrollTo({top:0,behavior:"smooth"})}function A(){if(!s.draft.moodId)return p("请先选择一种情绪");const i={id:"e"+Date.now(),moodId:s.draft.moodId,intensity:Number(s.draft.intensity),triggers:[...s.draft.triggers],note:s.draft.note.trim(),createdAt:Date.now()};s.entries=[i,...s.entries],S(),s.draft={moodId:i.moodId,intensity:5,triggers:[],note:""},p("已记下这一刻，给你推荐调节方案"),g("care")}function D(){return`
    <header class="topbar">
      <div class="brand">
        <div class="brand-mark">心迹</div>
        <div class="brand-sub">情绪日记与自我关怀</div>
      </div>
      <nav class="nav">
        ${[["home","首页"],["record","记录"],["insight","洞察"],["care","关怀"],["diary","日记"]].map(([t,n])=>`<button data-nav="${t}" class="${s.view===t?"active":""}">${n}</button>`).join("")}
      </nav>
    </header>
  `}function h(){const i=s.entries[0],t=i?l(i.moodId):null;return`
    <section class="hero">
      <div class="hero-copy">
        <h1>把情绪写下来，再温柔对待自己</h1>
        <p>面对学业、职场与社交压力时，用 30 秒完成一次低门槛记录，看清触发因素，并获得可马上做的自我调节方案。</p>
        <div class="cta-row">
          <button class="btn-primary" data-nav="record">开始记录情绪</button>
          <button class="btn-ghost" data-nav="insight">查看情绪洞察</button>
        </div>
      </div>
      <div class="hero-panel">
        <h2>此刻感觉如何？</h2>
        <p>${t?`上次你记录了「${t.name}」，强度 ${i.intensity}/10。`:"点选一个情绪，快速进入记录。"}</p>
        <div class="mood-mini">
          ${m.slice(0,5).map(n=>`<button data-quick="${n.id}" title="${n.name}">${n.emoji}</button>`).join("")}
        </div>
      </div>
    </section>
    <section class="section">
      <div class="section-head">
        <div>
          <h2>今日建议路径</h2>
          <p>记录 → 看见触发因素 → 选择一个自助方案</p>
        </div>
      </div>
      <div class="grid-3">
        <article class="card care-card">
          <div>
            <span class="tag">01 记录</span>
            <h3>30 秒情绪签到</h3>
            <p>选情绪、标强度、点触发因素，不必写很长。</p>
          </div>
          <button class="btn-soft" data-nav="record">去记录</button>
        </article>
        <article class="card care-card">
          <div>
            <span class="tag">02 洞察</span>
            <h3>找到反复出现的触发点</h3>
            <p>自动汇总最常让你波动的场景与平均强度。</p>
          </div>
          <button class="btn-soft" data-nav="insight">看洞察</button>
        </article>
        <article class="card care-card">
          <div>
            <span class="tag">03 关怀</span>
            <h3>冥想 / 音乐 / 运动</h3>
            <p>按当前情绪推荐可执行的低门槛调节动作。</p>
          </div>
          <button class="btn-soft" data-nav="care">拿方案</button>
        </article>
      </div>
    </section>
  `}function L(){const i=s.draft;return`
    <section class="section">
      <div class="section-head">
        <div>
          <h2>记录这一刻</h2>
          <p>诚实就好，不评判对错</p>
        </div>
      </div>
      <div class="grid-2">
        <div class="card">
          <div class="field">
            <label>此刻情绪</label>
            <div class="mood-grid">
              ${m.map(t=>`
                <button class="mood-opt ${i.moodId===t.id?"selected":""}" data-mood="${t.id}">
                  <span class="emoji">${t.emoji}</span>
                  <span class="name">${t.name}</span>
                </button>`).join("")}
            </div>
          </div>
          <div class="field">
            <label>情绪强度</label>
            <div class="range-row">
              <input type="range" min="1" max="10" value="${i.intensity}" data-intensity />
              <div class="intensity-val">${i.intensity}/10</div>
            </div>
          </div>
          <div class="field">
            <label>可能的触发因素（可多选）</label>
            <div class="chips">
              ${$.map(t=>`<button class="chip ${i.triggers.includes(t)?"on":""}" data-trigger="${t}">${t}</button>`).join("")}
            </div>
          </div>
          <div class="field">
            <label>想说的话（可选）</label>
            <textarea data-note placeholder="发生了什么？身体有什么感觉？">${i.note}</textarea>
          </div>
          <button class="btn-primary" data-save>保存并获取关怀建议</button>
        </div>
        <div class="card">
          <h3 style="font-family:var(--font-display);margin-bottom:8px;">为什么这样设计？</h3>
          <p style="color:var(--ink-soft);margin-bottom:12px;">年轻人不是缺少“应该调节”的道理，而是缺少一个足够轻、足够私密、马上能做的入口。</p>
          <div class="insight-list">
            <div class="insight"><div>①</div><div><strong>低门槛</strong><div class="bar"><span style="width:90%"></span></div></div><div>30秒</div></div>
            <div class="insight"><div>②</div><div><strong>可复盘</strong><div class="bar"><span style="width:75%"></span></div></div><div>触发因素</div></div>
            <div class="insight"><div>③</div><div><strong>可行动</strong><div class="bar"><span style="width:85%"></span></div></div><div>自助方案</div></div>
          </div>
        </div>
      </div>
    </section>
  `}function O(){var r;const i=I(s.entries),t=E(s.entries),n=Math.max(...t.map(d=>d.avg),1),e=s.entries.length?(s.entries.reduce((d,c)=>d+c.intensity,0)/s.entries.length).toFixed(1):"-",a=((r=i[0])==null?void 0:r.name)||"暂无",o=new Set(s.entries.map(d=>d.moodId)).size;return`
    <section class="section">
      <div class="section-head">
        <div>
          <h2>情绪洞察</h2>
          <p>从记录里看见反复出现的模式</p>
        </div>
      </div>
      <div class="stats">
        <div class="stat"><strong>${s.entries.length}</strong><span>累计记录</span></div>
        <div class="stat"><strong>${e}</strong><span>平均强度</span></div>
        <div class="stat"><strong>${o}</strong><span>情绪种类</span></div>
      </div>
      <div class="grid-2">
        <div class="card">
          <h3 style="font-family:var(--font-display);margin-bottom:10px;">近 7 日情绪趋势</h3>
          <div class="chart">
            ${t.map(d=>`
              <div class="col">
                <div class="pill" style="height:${Math.max(8,d.avg/n*100)}%"></div>
                <small>${d.label.slice(d.label.indexOf("/")+1)}</small>
              </div>`).join("")}
          </div>
          <p style="margin-top:10px;color:var(--ink-soft);font-size:0.88rem;">柱越高代表当天情绪更偏积极/稳定。</p>
        </div>
        <div class="card">
          <h3 style="font-family:var(--font-display);margin-bottom:10px;">高频触发因素</h3>
          ${i.length===0?'<div class="empty">还没有足够数据，先去记录几次吧。</div>':`<div class="insight-list">
                ${i.slice(0,6).map(d=>{const c=l(d.topMood),b=Math.min(100,d.count*28);return`
                    <div class="insight">
                      <div>${c.emoji}</div>
                      <div>
                        <strong>${d.name}</strong>
                        <div class="bar"><span style="width:${b}%"></span></div>
                        <div style="font-size:0.78rem;color:var(--ink-soft);margin-top:4px;">常伴随「${c.name}」</div>
                      </div>
                      <div style="text-align:right;font-size:0.82rem;">${d.count}次<br/>均强 ${d.avg}</div>
                    </div>`}).join("")}
              </div>`}
          <p style="margin-top:12px;color:var(--ink-soft);font-size:0.88rem;">当前最值得关注的触发点：<strong>${a}</strong></p>
        </div>
      </div>
    </section>
  `}function q(){const i=s.entries[0],t=l(i?i.moodId:"calm"),n=x(t.id);return`
    <section class="section">
      <div class="section-head">
        <div>
          <h2>自我关怀方案</h2>
          <p>基于「${t.emoji} ${t.name}」为你推荐，选一个马上开始</p>
        </div>
        <button class="btn-ghost" data-nav="record">换个情绪重推</button>
      </div>
      <div class="grid-3">
        ${n.map(e=>`
          <article class="card care-card">
            <div>
              <span class="tag">${e.type}</span>
              <h3>${e.title}</h3>
              <p>${e.desc}</p>
            </div>
            <div class="meta"><span>约 ${e.mins} 分钟</span><button class="btn-soft" data-done="${e.title}">我做完了</button></div>
          </article>`).join("")}
      </div>
      <p class="disclaimer">心迹是自我觉察与日常调节工具，不能替代专业心理咨询或医疗诊断。若持续痛苦或有自伤风险，请寻求专业帮助。</p>
    </section>
  `}function k(){return`
    <section class="section">
      <div class="section-head">
        <div>
          <h2>情绪日记</h2>
          <p>你的私密记录保存在本机浏览器中</p>
        </div>
        <button class="btn-primary" data-nav="record">新记录</button>
      </div>
      <div class="card timeline">
        ${s.entries.length===0?'<div class="empty">还没有日记，从一次小记录开始。</div>':s.entries.map(i=>{const t=l(i.moodId);return`
                  <article class="entry">
                    <div class="emoji">${t.emoji}</div>
                    <div>
                      <h4>${t.name} · 强度 ${i.intensity}/10</h4>
                      <div class="note">${i.note||"（未写文字，只留下了情绪痕迹）"}</div>
                      <div class="tags">${i.triggers.map(n=>`<span>${n}</span>`).join("")}</div>
                    </div>
                    <div class="time">${j(i.createdAt)}</div>
                  </article>`}).join("")}
      </div>
    </section>
  `}function v(){const i=document.getElementById("app"),t={home:h,record:L,insight:O,care:q,diary:k};i.innerHTML=`
    <div class="app-shell">
      ${D()}
      ${(t[s.view]||h)()}
    </div>
    <div class="toast ${s.toast?"show":""}">${s.toast}</div>
  `,M()}function M(){document.querySelectorAll("[data-nav]").forEach(e=>{e.addEventListener("click",()=>g(e.getAttribute("data-nav")))}),document.querySelectorAll("[data-quick]").forEach(e=>{e.addEventListener("click",()=>{s.draft.moodId=e.getAttribute("data-quick"),g("record")})}),document.querySelectorAll("[data-mood]").forEach(e=>{e.addEventListener("click",()=>{s.draft.moodId=e.getAttribute("data-mood"),v()})}),document.querySelectorAll("[data-trigger]").forEach(e=>{e.addEventListener("click",()=>{const a=e.getAttribute("data-trigger"),o=new Set(s.draft.triggers);o.has(a)?o.delete(a):o.add(a),s.draft.triggers=[...o],v()})});const i=document.querySelector("[data-intensity]");i&&i.addEventListener("input",e=>{s.draft.intensity=e.target.value;const a=document.querySelector(".intensity-val");a&&(a.textContent=`${e.target.value}/10`)});const t=document.querySelector("[data-note]");t&&t.addEventListener("input",e=>{s.draft.note=e.target.value});const n=document.querySelector("[data-save]");n&&n.addEventListener("click",A),document.querySelectorAll("[data-done]").forEach(e=>{e.addEventListener("click",()=>p(`很棒，已完成「${e.getAttribute("data-done")}」`))})}v();
